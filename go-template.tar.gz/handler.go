package main

import (
	"net/http"

	"github.com/chinglinwen/log"

	"github.com/labstack/echo"
)

func homeHandler(c echo.Context) error {
	//may do redirect later?
	return c.String(http.StatusOK, "home page")
}

func hookHandler(c echo.Context) error {
	appname := c.FormValue("appname")
	env := c.FormValue("env")
	if appname == "" {
		return c.JSONPretty(400, E(1, "appname not provided", "error"), " ")
	}

	return c.JSONPretty(http.StatusOK, E(0, out, "ok"), " ")
}

func E(code int, msg, status string) map[string]interface{} {
	log.Println(msg)
	return map[string]interface{}{
		"code":    code,
		"message": msg,
		"status":  status,
	}
}

func EData(code int, msg, status string, data []map[string]interface{}) map[string]interface{} {
	log.Println(msg)
	return map[string]interface{}{
		"code":    code,
		"message": msg,
		"status":  status,
		"data":    data,
	}
}

func notifyHandler(c echo.Context) error {}
